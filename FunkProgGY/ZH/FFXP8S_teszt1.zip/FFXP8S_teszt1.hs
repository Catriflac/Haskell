--Horváth Dávid György / FFXP8S / 2022.09.20.

tripleMe x = x * 3

longestSide a b = sqrt(a * a + b * b)