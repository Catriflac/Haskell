--Horváth Dávid György / FFXP8S / 2022.09.20.

circleArea r = r * r * pi

cuboidArea a b c = 2 * (a * b + a * c + b * c)

cuboidVolume a b c = a * b * c

doubleMe x = x * 2