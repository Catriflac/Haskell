containsElements  :: [a] -> Bool
containsElements  [] = False
containsElements  _ = True

sectionOf :: [a] -> Int -> Int -> [a]
sectionOf a b c = undefined -- :(